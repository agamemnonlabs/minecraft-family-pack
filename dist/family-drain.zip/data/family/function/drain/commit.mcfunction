fill ~-15 ~-15 ~-15 ~15 ~15 ~15 minecraft:air replace minecraft:structure_void
execute as @e[type=minecraft:marker,tag=family.drain_wet] at @s run function family:drain/dry

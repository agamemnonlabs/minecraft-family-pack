execute as @e[type=minecraft:marker,tag=family.drain_o] at @s run function family:drain/undo
kill @e[type=minecraft:marker,tag=family.drain]

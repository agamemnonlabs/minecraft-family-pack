execute unless entity @e[type=minecraft:marker,tag=family.drain_o,distance=..15] run return run scoreboard players set #leak family.drain 1
scoreboard players add #cells family.drain 1
execute if score #cells family.drain matches 1501.. run return run scoreboard players set #leak family.drain 2
execute if block ~ ~ ~ minecraft:water run setblock ~ ~ ~ minecraft:structure_void
execute unless block ~ ~ ~ minecraft:structure_void run summon minecraft:marker ~ ~ ~ {Tags:["family.drain","family.drain_wet"]}
execute if score #leak family.drain matches 0 positioned ~1 ~ ~ run function family:drain/try
execute if score #leak family.drain matches 0 positioned ~-1 ~ ~ run function family:drain/try
execute if score #leak family.drain matches 0 positioned ~ ~1 ~ run function family:drain/try
execute if score #leak family.drain matches 0 positioned ~ ~-1 ~ run function family:drain/try
execute if score #leak family.drain matches 0 positioned ~ ~ ~1 run function family:drain/try
execute if score #leak family.drain matches 0 positioned ~ ~ ~-1 run function family:drain/try

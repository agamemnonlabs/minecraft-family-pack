fill ~-15 ~-15 ~-15 ~15 ~15 ~15 minecraft:water replace minecraft:structure_void

execute if block ~ ~ ~ minecraft:water run return run function family:drain/visit
execute if predicate family:drain/wet unless entity @e[type=minecraft:marker,tag=family.drain_wet,distance=..0.5] run function family:drain/visit

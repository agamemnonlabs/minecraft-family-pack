execute positioned ~1 ~ ~ if block ~ ~ ~ minecraft:air run return run function family:drain/sponge
execute positioned ~-1 ~ ~ if block ~ ~ ~ minecraft:air run return run function family:drain/sponge
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:air run return run function family:drain/sponge
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:air run return run function family:drain/sponge
execute positioned ~ ~ ~1 if block ~ ~ ~ minecraft:air run return run function family:drain/sponge
execute positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:air run return run function family:drain/sponge

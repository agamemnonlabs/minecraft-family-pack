scoreboard objectives add family.drain dummy
scoreboard players set #cells family.drain 0
scoreboard players set #leak family.drain 0
kill @e[type=minecraft:marker,tag=family.drain]
summon minecraft:marker ~ ~ ~ {Tags:["family.drain","family.drain_o"]}
schedule function family:drain/rescue 1t replace
function family:drain/visit
execute if score #leak family.drain matches 0 run function family:drain/commit
execute unless score #leak family.drain matches 0 run function family:drain/undo
execute if score #leak family.drain matches 0 run tellraw @s [{"text": "Drained ", "color": "green"}, {"score": {"name": "#cells", "objective": "family.drain"}, "color": "green"}, {"text": " blocks of water.", "color": "green"}]
execute if score #leak family.drain matches 1 run tellraw @s [{"text": "Can't drain: this water reaches the sea, so there's a gap somewhere. Nothing changed. Look for a missing block, or a glass pane, fence, stairs, slab or trapdoor in the outer walls, roof or floor.", "color": "red"}]
execute if score #leak family.drain matches 2 run tellraw @s [{"text": "Can't drain: this room holds more than 1500 blocks of water, too much for one go. Nothing changed.", "color": "red"}]
kill @e[type=minecraft:marker,tag=family.drain]

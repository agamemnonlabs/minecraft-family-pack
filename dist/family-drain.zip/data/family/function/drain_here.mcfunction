execute unless entity @s[type=minecraft:player] run return fail
execute at @s align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~ ~ minecraft:water run return run function family:drain/start
execute at @s align xyz positioned ~0.5 ~1.5 ~0.5 if block ~ ~ ~ minecraft:water run return run function family:drain/start
tellraw @s [{"text": "Stand in the water inside the room you want to drain, then run this again.", "color": "yellow"}]
